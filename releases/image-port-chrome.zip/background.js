(()=>{chrome.action.onClicked.addListener(async e=>{try{await chrome.tabs.sendMessage(e.id,{type:"image-port:toggle"})}catch{await chrome.tabs.create({url:chrome.runtime.getURL("app.html")})}});})();
