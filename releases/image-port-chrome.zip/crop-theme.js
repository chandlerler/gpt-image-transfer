(()=>{try{localStorage.getItem("iz-theme")==="dark"&&document.documentElement.setAttribute("data-theme","dark")}catch{}})();
